localWorld: dict = {
    "localWorld.no_local_world_label":"你尚未创建任何世界。",
    "localWorld.no_local_worlds_present":"您的世界消失了？试试看更改存储位置：",
    "localWorld.no_local_worlds_present.world_recovery":"您的世界消失了？请尝试在外部存储器中恢复世界：",
    "localWorld.no_local_worlds.world_recovery_button_label":"恢复世界",

}