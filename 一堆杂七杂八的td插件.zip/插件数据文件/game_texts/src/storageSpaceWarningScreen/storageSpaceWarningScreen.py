storageSpaceWarningScreen: dict = {
    "storageSpaceWarningScreen.frontend":"您的存储空间即将不足！《我的世界》已限制您访问该功能，直至您清理出额外的存储空间为止。",
    "storageSpaceWarningScreen.lowduringgameplay":"您的设备空间不足，Minecraft 无法在此设备上存储世界和设置。为什么不删除一些您不需要的旧东西，便于您保存新内容？",
    "storageSpaceWarningScreen.fullduringgameplay":"您的存储空间不足，《我的世界》无法保存您的进度！ 《我的世界》 将帮助您回到主菜单，以清理出额外的存储空间。",

}