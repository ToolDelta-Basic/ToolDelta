seargeSays: dict = {
        "seargeSays.searge1":"及时享乐",
    "seargeSays.searge2":"/achievement take achievement.understandCommands @p",
    "seargeSays.searge3":"在 twitter 上寻求帮助",
    "seargeSays.searge4":"/deop @p",
    "seargeSays.searge5":"删除记分板，阻止命令",
    "seargeSays.searge6":"联系支持人员以寻求帮助",
    "seargeSays.searge7":"/testfornoob @p",
    "seargeSays.searge8":"/trigger warning",
    "seargeSays.searge9":"噢我的天啊，全是统计数据",
        "seargeSays.searge11":"你试过关闭后再重新打开吗？",
    "seargeSays.searge12":"抱歉，今天没有帮上忙",

}