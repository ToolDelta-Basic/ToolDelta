color: dict = {
    "color.black":"黑色",
    "color.dark_blue":"深蓝色",
    "color.dark_green":"深绿色",
    "color.dark_aqua":"深水绿色",
    "color.dark_red":"深红色",
    "color.dark_purple":"暗紫色",
    "color.gold":"金色",
    "color.gray":"灰色",
    "color.dark_gray":"深灰色",
    "color.blue":"蓝色",
    "color.green":"绿色",
    "color.aqua":"水绿色",
    "color.red":"红色",
    "color.light_purple":"浅紫色",
    "color.yellow":"黄色",
    "color.white":"白色",

}