ratingPopUp: dict = {
    "ratingPopUp.title":"喜欢《我的世界》吗？",

}