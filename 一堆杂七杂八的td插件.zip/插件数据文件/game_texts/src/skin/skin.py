skin: dict = {
    "skin.New":"新",
    "skin.Standard.Custom":"自定义",
    "skin.Standard.CustomSlim":"自定义",
    "skin.Standard.Dummy":"自定义",

}