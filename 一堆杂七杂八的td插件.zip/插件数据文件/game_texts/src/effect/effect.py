effect: dict = {
    "effect.badOmen":"凶兆",
    "effect.villageHero":"村庄英雄",
    "effect.darkness":"黑暗",

}