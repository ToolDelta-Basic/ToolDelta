tutorial: dict = {
    "tutorial.edu.menuTitle":"玩法学习",
    "tutorial.edu.title":"教程",

}