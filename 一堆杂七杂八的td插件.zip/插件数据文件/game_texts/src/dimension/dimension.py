dimension: dict = {
    "dimension.dimensionName0":"主世界",
    "dimension.dimensionName1":"下界",
    "dimension.dimensionName2":"末地",

}