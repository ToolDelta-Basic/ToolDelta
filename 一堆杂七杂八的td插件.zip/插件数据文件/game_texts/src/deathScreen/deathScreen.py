deathScreen: dict = {
    "deathScreen.deleteWorld":"删除世界",
    "deathScreen.hardcoreInfo":"你不可在极限模式中重生！",
    "deathScreen.leaveServer":"退出服务器",
    "deathScreen.message":"你失败了！",
    "deathScreen.quit":"主菜单",
    "deathScreen.quit.confirm":"你确定要退出吗？",
    "deathScreen.quit.confirmToMainMenuWarning":"是否确定要退出游戏进入主菜单？",
    "deathScreen.quit.confirmToMainMenuTitleWarning":"退出到主菜单？",
    "deathScreen.quit.secondaryClient":"保存并退出",
    "deathScreen.quit.secondaryClient.confirmLeaveWarning":"是否确实要保存并退出游戏？",
    "deathScreen.quit.secondaryClient.confirmLeaveTitleWarning":"保存并退出",
    "deathScreen.respawn":"重生",
    "deathScreen.score":"分数",
    "deathScreen.title":"你失败了！",
    "deathScreen.title.hardcore":"游戏结束！",
    "deathScreen.titleScreen":"标题画面",

}