script: dict = {
    "script.description":"调试游戏测试框架的选项。",
    "script.error.unknownCommandMode":"提供的命令模式未知",
    "script.error.noDebugger":"调试器无法使用",
    "script.error.debuggerFailed":"无法启动调试器",
    "script.error.profilerStopped":"分析器已停止。无法保存档案。",
    "script.error.statsSaved":"无法保存脚本统计信息",
    "script.success.debuggerListen":"调试器正在监听端口 %s",
    "script.success.debuggerConnect":"调试器已连接到端口 %s 上的主机 %s",
    "script.success.debuggerClosed":"调试器已关闭",
    "script.success.profilerStarted":"分析器已启动",
    "script.success.profilerStopped":"分析器已停止。档案已保存到 '%s'	 Full path to profile file",
    "script.success.statsSaved":"脚本统计信息已保存到 '%s'                   	 Full path to stats file",

}