start: dict = {
    "start.beta.icon":"Beta 版",

}