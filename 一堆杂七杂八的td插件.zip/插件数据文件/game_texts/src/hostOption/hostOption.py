hostOption: dict = {
    "hostOption.codeBuilder":"代码编辑器",
    "hostOption.setWorldSpawn":"设置世界出生点",
    "hostOption.teleport":"传送",
    "hostOption.teleport.who":"谁",
    "hostOption.teleport.where":"何处",
    "hostOption.time":"时间",
    "hostOption.time.day":"白日",
    "hostOption.time.midnight":"午夜",
    "hostOption.time.noon":"中午",
    "hostOption.time.night":"夜晚",
    "hostOption.time.sunrise":"日出",
    "hostOption.time.sunset":"日落",
    "hostOption.weather":"天气",
    "hostOption.weather.clear":"晴天",
    "hostOption.weather.rain":"雨天",
    "hostOption.weather.thunderstorm":"雷暴",

}