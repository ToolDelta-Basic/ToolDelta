realmsPlusUpgradeNotice: dict = {
    "realmsPlusUpgradeNotice.title":"欢迎使用 Realms Plus！",
    "realmsPlusUpgradeNotice.body":"您的 Realms 定期服务已升级为 Realms Plus。现在您无需花费额外的费用，即可访问来自市场的 150 多个内容包。至多 10 名玩家可以同时玩，并且他们可以访问您的 Realm 内的所有订阅内容——免费地！",
    "realmsPlusUpgradeNotice.continue":"继续",
    "realmsPlusUpgradeNotice.viewpacks":"查看 Realms Plus 包",

}