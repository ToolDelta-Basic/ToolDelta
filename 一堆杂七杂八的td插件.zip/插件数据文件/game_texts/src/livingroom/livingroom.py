livingroom: dict = {
    "livingroom.hint.tap_touchpad_for_immersive":"点击触控板可切换沉浸模式",
    "livingroom.hint.tap_view_for_immersive":"按下 F5 键切换沉浸模式",
    "livingroom.hint.tap_view_for_immersive_gamepad":"按向上方向键可切换沉浸模式",
    "livingroom.hint.tap_view_for_immersive_oculustouch":"按 Y 可切换沉浸模式",
    "livingroom.hint.tap_view_for_immersive_windowsmr":"按下右菜单切换沉浸模式",

}