compliance: dict = {
    "compliance.playtime.greaterThan24Hours":"您玩游戏的时间已超过 24 小时",
    "compliance.playtime.message":"过度游戏可能会干扰正常的日常生活",
    "compliance.playtime.multipleHours":"您玩游戏的时间已达到 %d 小时",
    "compliance.playtime.oneHour":"您玩游戏的时间已达到 1 小时",

}