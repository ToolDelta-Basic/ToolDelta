inventory: dict = {
    "inventory.binSlot":"摧毁物品",

}