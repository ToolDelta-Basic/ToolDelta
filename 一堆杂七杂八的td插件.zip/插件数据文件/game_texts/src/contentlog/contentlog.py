contentlog: dict = {
    "contentlog.history.title":"内容日志历史",
    "contentlog.history.copyToClipboard":"复制到剪贴板",
        "contentlog.settingsSectionName":"内容日志设置",
    "contentlog.clear_files":"删除旧的日志",
    "contentlog.delete.title":"删除旧的日志文件？",
    "contentlog.delete.body1":"选择“立即删除”以删除所有之前的日志文件。",
    "contentlog.delete.body2":"注意：您当前活动会话的日志文件将保留。",
    "contentlog.delete.delete":"立即删除",
    "contentlog.delete.cancel":"取消",
    "contentlog.delete.progress":"正在删除内容日志",

}