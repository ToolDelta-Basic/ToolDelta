advMode: dict = {
            "advMode.command":"命令输入",
        "advMode.notAllowed":"必须是处于创造模式的管理员",
    "advMode.notEnabled":"命令方块在此服务器上未启用",
    "advMode.previousOutput":"上一个输出",
            "advMode.setCommand":"设置此模块的控制台指令",
    "advMode.setCommand.success":"成功设置：%s",

}