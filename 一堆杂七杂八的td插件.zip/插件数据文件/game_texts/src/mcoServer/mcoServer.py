mcoServer: dict = {
    "mcoServer.title":"《我的世界》Online世界",

}