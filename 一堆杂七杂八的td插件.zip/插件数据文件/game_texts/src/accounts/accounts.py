accounts: dict = {
    "accounts.name":"姓名：%s (%s)",
    "accounts.signedInAs":"登录身份为",
    "accounts.signOutConfirmation":"是否要注销并切换账户？",
    "accounts.switchConfirmation":"您想要切换帐户吗？您的当前帐户将保持登录状态。",
    "accounts.signOut":"注销",
    "accounts.switch":"切换账户",
    "accounts.manage":"管理帐户",

}