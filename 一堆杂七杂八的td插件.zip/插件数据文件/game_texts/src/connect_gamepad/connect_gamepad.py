connect_gamepad: dict = {
    "connect_gamepad.warning.controllerRequired":"需要游戏控制器",
    "connect_gamepad.pressButtonToContinue":"请在控制器上按 'A' 按钮继续",

}