clientscript: dict = {
    "clientscript.description":"游戏测试框架的客户端调试选项。",
    "clientscript.error.unknownCommandMode":"提供的命令模式未知",
    "clientscript.error.noDebugger":"客户端调试器不可用",
    "clientscript.error.debuggerFailed":"无法启动客户端调试器",
    "clientscript.success.debuggerListen":"客户端调试器监听端口 %s",
    "clientscript.success.debuggerConnect":"客户端调试器已连接到端口 %s 上的主机 %s",
    "clientscript.success.debuggerClosed":"客户端调试器已关闭",

}