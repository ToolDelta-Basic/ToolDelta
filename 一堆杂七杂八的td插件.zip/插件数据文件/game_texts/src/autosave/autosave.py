autosave: dict = {
    "autosave.title":"自动保存",
    "autosave.info.general":"当您看到此图标时，我们正在保存您的游戏。当屏幕上出现此图标时，请不要关闭您的设备。",
    "autosave.info.nx":"当您看到此图标时，我们正在保存您的游戏。当屏幕上出现此图标时，请不要关闭您的 Nintendo Switch。",
    "autosave.info.xbox":"当您看到此图标时，我们正在保存您的游戏。当屏幕上出现此图标时，请不要关闭您的 Xbox。",
    "autosave.info.desktop":"当您看到此图标时，我们正在保存您的游戏。当屏幕上出现此图标时，请不要关闭您的电脑。",

}