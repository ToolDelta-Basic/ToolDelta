osk: dict = {
    "osk.truncation_warning.title":"警告",
    "osk.truncation_warning.body":"无法编辑文本。文本超出限制，并可能导致截断或数据丢失。",

}