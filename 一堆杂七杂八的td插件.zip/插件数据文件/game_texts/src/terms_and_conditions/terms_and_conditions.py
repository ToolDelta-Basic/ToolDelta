terms_and_conditions: dict = {
    "terms_and_conditions.goBack":"返回",
    
}