commandBlock: dict = {
    "commandBlock.shortName":"@",
    "commandBlock.genericName":"命令方块",

}