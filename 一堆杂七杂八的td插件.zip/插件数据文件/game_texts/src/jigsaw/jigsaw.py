jigsaw: dict = {
    "jigsaw.title.target_pool":"目标池：",
    "jigsaw.title.name":"名称：",
    "jigsaw.title.target":"目标名称：",
    "jigsaw.title.final_block":"变为：",
    "jigsaw.title.joint_type":"接点类型：",
    "jigsaw.title.joint_type.aligned":"一致",
    "jigsaw.joint_type.aligned":"一致",
    "jigsaw.joint_type.rollable":"可滚动",
    "jigsaw.exit.done":"完成",
    "jigsaw.exit.cancel":"取消",

}