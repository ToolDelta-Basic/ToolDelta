crafting: dict = {
    "crafting.badCombination":"该物品无有效输出",
    "crafting.cannotCreate":"你没有全部的原料",
    "crafting.insufficientLevel":"您的等级过低",
    "crafting.noRecipesInventory":"你需要收集制造用的方块！",
    "crafting.noRecipesStonecutter":"你需要制造用的石材！",
    "crafting.noRecipesStonecutter_block":"您需要合成用的石头材料！",
    "crafting.noRecipesWorkbench":"你需要收集制造用的方块！",

}