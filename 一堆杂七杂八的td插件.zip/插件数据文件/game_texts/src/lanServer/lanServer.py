lanServer: dict = {
    "lanServer.otherPlayers":"对其他玩家的设置",
    "lanServer.scanning":"正在你的本地网络中寻找游戏",
    "lanServer.start":"创造一个局域网世界",
    "lanServer.title":"局域网世界",
    "lanServer.restart":"该服务器已重启！",

}