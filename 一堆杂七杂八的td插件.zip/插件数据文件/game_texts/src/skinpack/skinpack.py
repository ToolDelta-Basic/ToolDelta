skinpack: dict = {
    "skinpack.Education":"Education Edition 皮肤",

}