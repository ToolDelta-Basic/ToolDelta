recipeBook: dict = {
    "recipeBook.setting.full":"满",
    "recipeBook.setting.discover":"发现",
    "recipeBook.setting.off":"关闭",

}