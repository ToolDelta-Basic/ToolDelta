seedPicker: dict = {
    "seedPicker.search":"搜索",
    "seedPicker.title":"种子采摘机",

}