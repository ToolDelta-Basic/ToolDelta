persona: dict = {
    "persona.slim.title":"窄的",
    "persona.wide.title":"宽",
    "persona.smaller.title":"较小",
    "persona.small.title":"小",
    "persona.medium.title":"中",
    "persona.tall.title":"高",
    "persona.realms.redeem":"兑换",
    "persona.realms.see.subscription":"在 Realms Plus 中",
    "persona.realms.time.remaining":"%s 以兑换",
    "persona.realms.savings":"通过订阅 Realms Plus，您可以节省 %s 个 Minecoin！",

}