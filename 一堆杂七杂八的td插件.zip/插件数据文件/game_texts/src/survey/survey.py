survey: dict = {
    "survey.feedbackButton":"给我们发送您的反馈",
    "survey.label":"选择所有适用项：",
    "survey.line1":"载入时间过长",
    "survey.line2":"被错误消息卡住",
    "survey.line3":"询问太多问题",
    "survey.line4":"我不知道是免费",
    "survey.line5":"我以为需要 Xbox 主机	disable_3rd_party_console_resource_pack_check",
    "survey.line6":"不感兴趣",
    "survey.title":"反馈：您为什么没有注册？",

}