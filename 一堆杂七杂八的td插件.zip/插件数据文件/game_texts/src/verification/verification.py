verification: dict = {
    "verification.nolicense.title":"证书错误",
    "verification.nolicense.description":"我们在确认您在这个设备上拥有《我的世界》时遇到了困难。请确保您已经从商店下载并安装了《我的世界》。或者直接重新连接到互联网并再试一次。",

}