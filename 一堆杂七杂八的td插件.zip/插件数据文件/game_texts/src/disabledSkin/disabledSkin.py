disabledSkin: dict = {
    "disabledSkin.title":"您当前显示的身份为史蒂夫",
    "disabledSkin.body.onJoin":"此服务器已禁用%s。您可以在更衣室更换其他皮肤。",
    "disabledSkin.body.dressingRoom":"此服务器已禁用%s。确定要继续穿戴这款皮肤吗？",
    "disabledSkin.type.customSkins":"自定义皮肤",
    "disabledSkin.type.persona":"角色",
    "disabledSkin.type.both":"自定义皮肤和角色",

}