realmsSlotsScreen: dict = {
    "realmsSlotsScreen.description":"选择最多三个世界上传到您的 Realms 服务器。选择一个世界来进行激活或编辑！",
    "realmsSlotsScreen.new":"新的世界",
    "realmsSlotsScreen.readyToPlay":"准备游玩",
    "realmsSlotsScreen.editRealm":"管理 Realm",
    "realmsSlotsScreen.editWorld":"编辑世界",
    "realmsSlotsScreen.activateWorld":"激活世界",
    "realmsSlotsScreen.gamesettings":"游戏设置",
    "realmsSlotsScreen.chooseSlot":"选择插槽",
    "realmsSlotsScreen.activateWarning":"如果您编辑或激活这个世界，您会踢出所有活跃玩家。别担心，他们可以重新加入。",
    "realmsSlotsScreen.celebrationMap":"Realms 庆祝地图",

}