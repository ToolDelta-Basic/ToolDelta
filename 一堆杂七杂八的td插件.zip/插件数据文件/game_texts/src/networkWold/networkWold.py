networkWold: dict = {
    "networkWold.joinByCodeHelpText":"如果您已收到 Realm 邀请链接，输入代码即可加入。",

}