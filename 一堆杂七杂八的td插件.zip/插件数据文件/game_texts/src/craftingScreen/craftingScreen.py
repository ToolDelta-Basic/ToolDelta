craftingScreen: dict = {
    "craftingScreen.tab.search":"全部",
    "craftingScreen.tab.search.filter":"可合成",
    "craftingScreen.tab.construction":"建筑",
    "craftingScreen.tab.nature":"自然",
    "craftingScreen.tab.equipment":"装备",
    "craftingScreen.tab.items":"物品",
    "craftingScreen.tab.survival":"物品栏",
    "craftingScreen.tab.armor":"盔甲",

}