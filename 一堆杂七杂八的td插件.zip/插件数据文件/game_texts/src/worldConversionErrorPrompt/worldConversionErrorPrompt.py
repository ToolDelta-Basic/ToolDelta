worldConversionErrorPrompt: dict = {
    "worldConversionErrorPrompt.title":"世界转换失败",
    "worldConversionErrorPrompt.message":"槽糕，在世界转换过程中出错了。请稍后再试。",

}