chestScreen: dict = {
    "chestScreen.header.large":"大箱子",
    "chestScreen.header.player":"物品栏",
    "chestScreen.header.small":"箱子",

}