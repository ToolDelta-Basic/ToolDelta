usermanagement: dict = {
    "usermanagement.changeUser":"更改用户",

}