cauldronScreen: dict = {
    "cauldronScreen.header":"炼药锅",

}