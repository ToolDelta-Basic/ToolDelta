screenshot: dict = {
    "screenshot.failure":"无法保存截图：%s",
    "screenshot.success":"已将截图保存为%s",
    "screenshot.title":"屏幕截图已捕获！",
    "screenshot.caption":"添加标题并共享？",
    "screenshot.post":"共享",

}