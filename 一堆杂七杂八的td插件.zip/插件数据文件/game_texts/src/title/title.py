title: dict = {
    "title.oldgl1":"检测到旧式显卡；由于需要OpenGL 2.0，",
    "title.oldgl2":"这可能会在未来阻止您进行游戏。",

}