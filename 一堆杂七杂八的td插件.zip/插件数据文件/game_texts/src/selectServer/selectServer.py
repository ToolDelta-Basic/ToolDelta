selectServer: dict = {
    "selectServer.add":"添加服务器",
    "selectServer.defaultName":"《我的世界》服务器",
    "selectServer.delete":"删除",
    "selectServer.deleteButton":"删除",
    "selectServer.deleteQuestion":"确定要删除此服务器吗?",
    "selectServer.deleteWarning":"将会永久失去！( 无法恢复！)",
    "selectServer.direct":"直接连接",
    "selectServer.edit":"编辑",
    "selectServer.empty":"空",
    "selectServer.hiddenAddress":" (隐藏)",
    "selectServer.refresh":"刷新",
    "selectServer.select":"加入服务器",
    "selectServer.title":"选择服务器",

}