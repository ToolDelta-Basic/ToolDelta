eula: dict = {
    "eula.intro":"要使用 Minecraft Education，你必须接受最终用户许可协议。",
    "eula.location":"EULA 地址：",
    "eula.title":"最终用户许可协议",
    "eula.view":"查看最终用户许可协议",
    "eula.callToAction":"点击“接受”以接受该协议条款。",
    "eula.acceptButton":"接受",

}