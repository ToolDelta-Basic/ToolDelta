commandBlockScreen: dict = {
    "commandBlockScreen.blockType":"方块类型：",
    "commandBlockScreen.blockType.impulse":"脉冲",
    "commandBlockScreen.blockType.chain":"连锁",
    "commandBlockScreen.blockType.repeat":"重复",
    "commandBlockScreen.condition":"条件：",
    "commandBlockScreen.condition.conditional":"有条件的",
    "commandBlockScreen.condition.unconditional":"无条件",
    "commandBlockScreen.redstone":"红石：",
    "commandBlockScreen.redstone.needs_redstone":"需要红石",
    "commandBlockScreen.redstone.always_on":"始终活动",
        "commandBlockScreen.executeFirstTick":"执行第一个已选项",
    "commandBlockScreen.displayOutputMode":"O",
    "commandBlockScreen.hideOutputMode":"X",
    "commandBlockScreen.hoverNote":"悬停说明",
    "commandBlockScreen.title":"命令方块",

}