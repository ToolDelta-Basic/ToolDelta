client: dict = {
    "client.version.generic":"更新 %s",
    "client.version.1.0":"末影人更新 (%s)",
    "client.version.1.1":"发现更新 (%s)",
    "client.version.1.2":" Better Together 更新 (%s)",
    "client.version.1.4":"水生更新 (%s)",
    "client.version.1.5":"水生更新 (%s)",
    "client.version.1.11":"村庄和劫掠者村庄更新 (%s)",

}