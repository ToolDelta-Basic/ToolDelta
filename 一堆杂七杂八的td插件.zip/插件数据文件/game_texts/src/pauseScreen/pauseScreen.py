pauseScreen: dict = {
    "pauseScreen.back":"回到游戏",
    "pauseScreen.currentWorld":"当前世界",
    "pauseScreen.header":"游戏菜单",
    "pauseScreen.options":"选项",
    "pauseScreen.quit":"保存并退出",
    "pauseScreen.secondaryClientLeave":"保存和退出",
    "pauseScreen.feed":"动态信息",
    "pauseScreen.invite":"邀请加入游戏",
    "pauseScreen.ipAddress":"IP：%1",
    "pauseScreen.error.noIpAddress":"没有找到IP",
    "pauseScreen.error.noPort":"未发现端口",
    "pauseScreen.title":"游戏暂停",
    "pauseScreen.betaFeedback":"测试版反馈",
    "pauseScreen.xboxLiveDisconnect":"糟糕！您的 Microsoft 账户已断开连接。要使用在线功能，请在主菜单登录，并重新打开您的世界。",
    "pauseScreen.joinCode.Label":"加入代码",
    
}