raycasting: dict = {
    "raycasting.purchase.error":"我们检测到您的设备不符合运行此包的系统要求，因此您无法下载此包。您可以在下方查看最低系统要求：%s+ GPU：硬件支持光线追踪的 GPU，如 NVIDIA GeForce RTX 2060 或以上。有关详细信息，请前往 minecraft.net 参阅我们的常见问题解答。%s+ RAM：8GB 或以上 %s+ CPU：Intel Core i5 或类似性能的 CPU	the %s will be turned into linebreaks. Don't reorder.",
    "raycasting.purchase.error.title":"系统要求警告",

}