npcUri: dict = {
    "npcUri.launch.success":"已打开 NPC 链接。",
    "npcUri.launch.failure":"无法打开 NPC 链接。此 URL 似乎不受支持。",

}