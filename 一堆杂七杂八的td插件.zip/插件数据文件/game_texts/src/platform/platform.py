platform: dict = {
    "platform.model.unknown":"未知",

}