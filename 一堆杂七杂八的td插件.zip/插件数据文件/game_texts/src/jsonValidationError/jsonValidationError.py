jsonValidationError: dict = {
    "jsonValidationError.typeError":"%s：无效的属性类型。应为 %s，但为 %s",
    "jsonValidationError.requiredPropertyError":"%s：无法找到所需属性“%s”",
    "jsonValidationError.invalidValueError":"%s：未找到属性的有效值。应为 %s",

}