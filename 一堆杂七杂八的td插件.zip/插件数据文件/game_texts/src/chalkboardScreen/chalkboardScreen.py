chalkboardScreen: dict = {
    "chalkboardScreen.header":"编辑文本",
    "chalkboardScreen.locked":"已锁定",
    "chalkboardScreen.unlocked":"已解除锁定",

}