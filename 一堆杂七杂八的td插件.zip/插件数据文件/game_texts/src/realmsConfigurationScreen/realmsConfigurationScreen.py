realmsConfigurationScreen: dict = {
    "realmsConfigurationScreen.realmName":"Realm 名称",
    "realmsConfigurationScreen.realmDescription":"Realm 描述",
    "realmsConfigurationScreen.open":"打开 Realm",
    "realmsConfigurationScreen.close":"关闭 Realm",
    "realmsConfigurationScreen.resetRealm":"重置 Realm 会永远清除世界并重头开始。您确定要这样做吗？",
    "realmsConfigurationScreen.confirmReset":"确认重置",
    "realmsConfigurationScreen.resetRealmTryAgain":"重置 Realm 失败。是否要重试？",
    "realmsConfigurationScreen.failedOpenCloseTitle":"打开/关闭失败。",
    "realmsConfigurationScreen.failedOpenClose":"打开/关闭 Realm 失败。是否要重试？",

}