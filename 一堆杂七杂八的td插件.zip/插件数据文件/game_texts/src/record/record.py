record: dict = {
    "record.nowPlaying":"正在播放：%s",

}