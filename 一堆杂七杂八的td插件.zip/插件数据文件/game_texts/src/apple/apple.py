apple: dict = {
    "apple.iCloudDisabled.title":"别失去你的世界！",
    "apple.iCloudDisabled.message":"你的世界没有保存妥当。下次你玩《我的世界》时，它们可能不存在了。请前往 Apple TV 设置，开启 iCloud，确保所有世界保存完好。",
    "apple.iCloudDisabled.button.turnOnICloud":"开启 iCloud",
    "apple.iCloudNoSpace.message":"你的 iCloud 可用空间不足，无法妥当保存世界。下次你玩《我的世界》时，它们可能不存在了。请释放 iCloud 账户上的空间，确保所有世界保存完好。",
    "apple.iCloudNoSpace.button.manageICloud":"管理 iCloud",
    "apple.iCloudNoInternet.message":"你需要互联网连接才能妥当保存世界。下次你玩《我的世界》时，它们可能不存在了。请重新连接到互联网，确保所有世界保存完好。",
    "apple.iCloudSignInRequired.title":"登录",
    "apple.iCloudSignInRequired.message":"您必须登录 iCloud 才能玩《我的世界》。请转到 Apple TV 设置并打开 iCloud。",
    "apple.iCloudUserChanged.message":"已经登录新的 iCloud 帐户。您将需要重新启动《我的世界》才能进入游戏。",
    "apple.LocalNetworkPermission.message":"《我的世界》想要访问您的本地网络。这将允许您和本地网络上的其他玩家一起游玩。拒绝此权限不会影响在线功能或游戏本身。但会导致您无法和同一网络中的玩家一起游玩。",

}