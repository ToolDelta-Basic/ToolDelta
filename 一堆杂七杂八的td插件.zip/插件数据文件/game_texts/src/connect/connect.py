connect: dict = {
    "connect.authorizing":"登入中...",
    "connect.connecting":"正在连接到服务器...",
    "connect.failed":"无法连接至服务器",

}