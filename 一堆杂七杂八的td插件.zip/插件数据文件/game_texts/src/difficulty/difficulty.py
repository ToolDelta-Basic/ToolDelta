difficulty: dict = {
    "difficulty.lock.question":"你确定你要锁定这个世界的难度吗？这会将这个世界的难度锁定为%1$s，并且永远无法再次改变难度。",
    "difficulty.lock.title":"锁定世界难度",

}