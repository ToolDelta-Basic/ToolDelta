updateScreen: dict = {
    "updateScreen.update":"更新",
    "updateScreen.updateRequired":"需要更新",
    "updateScreen.title":"版本已过期",
    "updateScreen.body":"更新到最新版本，以访问所有的新功能、与好友在线玩，或者看看市场里有什么新东西。",
    "updateScreen.commerceNotSupported.title":"无法访问市场",
    "updateScreen.commerceNotSupported.body":"该版本的《我的世界》无法再访问《我的世界》市场。更新至最新版本以恢复市场访问。",
    "updateScreen.packs.updateRequired":"请更新到最新版本，以下载您在《我的世界》市场购买的包。",
    "updateScreen.patchVersion":"%s 版补丁说明：",

}