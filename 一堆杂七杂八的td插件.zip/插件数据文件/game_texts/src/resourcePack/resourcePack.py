resourcepack: dict = {
    "resourcepack.City":"城市材质包",
    "resourcepack.Plastic":"塑料材质包",
    "resourcepack.Natural":"自然材质包",
    "resourcepack.Fantasy":"魔幻材质包",
    "resourcepack.Cartoon":"卡通材质包",
    "resourcepack.Candy":"糖果材质包",
    "resourcepack.FestiveMashup2016":"节日混搭 2016",
    "resourcepack.ChineseMythology":"中国神话混搭包",
    "resourcepack.Fallout":"《辐射》混搭",
    "resourcepack.MagicTheGathering.name":"万智牌",

}