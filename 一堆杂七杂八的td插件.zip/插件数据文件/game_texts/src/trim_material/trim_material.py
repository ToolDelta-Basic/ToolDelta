trim_material: dict = {
    "trim_material.amethyst.name":"紫水晶材料",
    "trim_material.copper.name":"铜材料",
    "trim_material.diamond.name":"钻石材料",
    "trim_material.emerald.name":"绿宝石材料",
    "trim_material.gold.name":"黄金材料",
    "trim_material.iron.name":"铁材料",
    "trim_material.lapis.name":"青金石材料",
    "trim_material.netherite.name":"下界合金材料",
    "trim_material.quartz.name":"石英材料",
    "trim_material.redstone.name":"红石材料",

}