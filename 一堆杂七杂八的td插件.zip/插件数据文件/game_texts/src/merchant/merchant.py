merchant: dict = {
    "merchant.deprecated":"交易一些其他东西来解锁！",

}