copyCoordinates: dict = {
    "copyCoordinates.copy_position_message":"已将当前位置复制到剪贴板：'%s'",
    "copyCoordinates.copy_facing_message":"已将朝向位置复制到剪贴板：'%s'",

}