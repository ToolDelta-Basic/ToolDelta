attribute: dict = {
    "attribute.modifier.plus.0":"+%d %s",
    "attribute.modifier.plus.1":"+%d%% %s",
    "attribute.modifier.plus.2":"+%d%% %s",
    "attribute.modifier.take.0":"-%d %s",
    "attribute.modifier.take.1":"-%d%% %s",
    "attribute.modifier.take.2":"-%d%% %s",
                "attribute.name.generic.maxHealth":"最大生命值",
    "attribute.name.generic.attackDamage":"攻击伤害",
    "attribute.name.generic.knockbackResistance":"击退抗性",
        "attribute.name.horse.jumpStrength":"马匹跳跃能力",
    "attribute.name.zombie.spawnReinforcements":"僵尸增援",

}