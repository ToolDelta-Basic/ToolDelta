customTemplatesScreen: dict = {
    "customTemplatesScreen.header":"导入的模板",

}