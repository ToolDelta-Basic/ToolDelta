command: dict = {
    "command.permissions.list.fail.filenotfound":"从文件列出权限失败，文件未找到。",
    "command.permissions.reload.fail.filenotfound":"从文件重新加载权限失败，文件未找到。",

}