externalServerScreen: dict = {
    "externalServerScreen.addServer":"添加服务器",
    "externalServerScreen.addServerTitle":"添加服务器：",
    "externalServerScreen.addServerDescription":"添加外部服务器需填写服务器名称和服务器 IP 地址。添加后，可在服务器列表中找到服务器进入游戏。",
    "externalServerScreen.header":"添加外部服务器",
    "externalServerScreen.label":"按IP/地址添加服务器",
    "externalServerScreen.serverAddress":"IP/地址",
    "externalServerScreen.serverAddressInput":"服务器IP或地址",
    "externalServerScreen.serverName":"名称",
    "externalServerScreen.serverNameInput":"服务器名称",
    "externalServerScreen.serverPort":"端口",
    "externalServerScreen.serverPortInput":"服务器端口",

}