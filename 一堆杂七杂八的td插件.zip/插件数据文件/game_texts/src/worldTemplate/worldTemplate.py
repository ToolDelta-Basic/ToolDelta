worldTemplate: dict = {
    "worldTemplate.festivemashup2016.name":"节日混搭 2016",
    "worldTemplate.redstonemansion.name":"红石大厦",
    "worldTemplate.chinesemythology.name":"中国神话混搭包",
    "worldTemplate.GreekMythology.name":"希腊神话混搭包",
    "worldTemplate.Skyrim.name":"《天际》混搭包",

}