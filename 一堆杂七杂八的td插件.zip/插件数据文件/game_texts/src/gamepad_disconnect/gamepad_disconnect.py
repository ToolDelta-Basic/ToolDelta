gamepad_disconnect: dict = {
    "gamepad_disconnect.reconnectController":"您的控制器已丢失连接。请重新连接您的控制器才能继续。",

}