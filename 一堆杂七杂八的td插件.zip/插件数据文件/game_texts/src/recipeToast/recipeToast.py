recipeToast: dict = {
    "recipeToast.newUnlock.title":"新配方已解锁！",
    "recipeToast.newUnlock.tts":" 新配方已解锁",
    "recipeToast.newUnlock.descriptionRecipeBook":"检查配方书",
    "recipeToast.newUnlock.descriptionCraftingTable":"在工作台查看",
    "recipeToast.newUnlock.descriptionStonecutterTable":"在切石机查看",
    "recipeToast.newUnlock.descriptionSmithingTable":"在锻造台查看",
    "recipeToast.newUnlock.descriptionCartographyTable":"在制图台查看",
    "recipeToast.newIngredient.title":"发现新成分！",
    "recipeToast.newIngredient.tts":" 新成分已发现",
    "recipeToast.newIngredient.description":"将其用于现有配方中",

}