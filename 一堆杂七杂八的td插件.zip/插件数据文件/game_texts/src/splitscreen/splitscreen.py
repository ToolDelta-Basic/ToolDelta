splitscreen: dict = {
    "splitscreen.joinPrompt":"以玩家 %s 身份加入",
    "splitscreen.unavailable.toastHeader":"拆分屏幕不可用",
    "splitscreen.unavailable.toastMessage":"第二位玩家当前无法加入。",
    "splitscreen.unavailable.toastBodyInfo":"点击查看更多信息。",
    "splitscreen.joyconError.toastHeader":"无法连接 Joy-Con！",
    "splitscreen.joyconError.toastMessage":"您要加入的游戏在本地网络模式已连接太多控制器。",

}