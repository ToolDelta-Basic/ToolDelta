realmsWorld: dict = {
    "realmsWorld.notAvailable":"你的设备不支持 Minecraft Realms。",
    "realmsWorld.ownerPay":"拥有人每月需要付费，其好友可以免费加入！",
    "realmsWorld.realmsDescription":"Realms 是《我的世界》里的私人世界，可供你和你的好友随时游玩。",
    "realmsWorld.realmsDescription.paragraph2":"即使 Realm 的主人离线，您仍然可以进入该 Realm 并使用任何运行《我的世界》的设备玩游戏！",
    "realmsWorld.realmsDescription.paragraph3":"今天就开始探索你的 Realm！",
    "realmsWorld.realmsDescription.Beta.line1":"Realms 是种简单安全的方法，能与好友分享《我的世界》中的世界，但在使用《我的世界》测试版时无法使用。",
    "realmsWorld.realmsDescription.Beta.line2":"如果您想停止使用测试版，并获得进入 Realms 的权限，请点击下方查看说明。",
    "realmsWorld.newRealm":"新 Realm",
    "realmsWorld.connectLive":"注册即可免费试玩！",
    "realmsWorld.owner":"所有人",
    "realmsWorld.leaveBeta":"退出测试版？",
    "realmsWorld.newRealmTrial":"开始 30 天免费试玩儿%s（第一月后，每月%s）",
    "realmsWorld.creatingWorld":"正在创建世界",

}