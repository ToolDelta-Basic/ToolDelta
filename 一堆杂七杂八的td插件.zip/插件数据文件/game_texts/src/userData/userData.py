userdata: dict = {
    "userdata.unrecoverable.text":"我们检测到您的用户设置已损坏，但未能恢复它们。",

}