worldConversionComplete: dict = {
    "worldConversionComplete.title":"转换已完成",
    "worldConversionComplete.load_prompt":"您想立即开始玩您的世界吗？",

}