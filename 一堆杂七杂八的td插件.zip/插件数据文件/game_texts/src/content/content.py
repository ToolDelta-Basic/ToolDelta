content: dict = {
    "content.import.failed":"导入 '%s' 失败",
    "content.import.failed.subtitle":"查看输出日志了解更多详情",
    "content.import.failed.subtitle_duplicate":"检测到重复资源包",
    "content.import.failed.subtitle_malformed_zip":"无效的 zip 存档",
    "content.import.failed.subtitle_premiumcontent":"这个世界中的内容不受 Minecraft Education 支持。",
    "content.import.failed.incompatible":"不支持的文件格式",
    "content.import.failed.title_premiumcontent":"不支持的内容",
    "content.import.succeeded":"成功导入 '%s'",
    "content.import.succeeded_with_warnings":"成功导入 '%s'，但附有警告",
    "content.import.succeeded_with_warnings.subtitle":"点击此处查看更多信息",
    "content.import.started":"导入已开始...",

}