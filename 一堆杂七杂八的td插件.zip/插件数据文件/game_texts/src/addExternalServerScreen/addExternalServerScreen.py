addExternalServerScreen: dict = {
    "addExternalServerScreen.addServer":"添加服务器",
    "addExternalServerScreen.nameTextBoxLabel":"服务器名称",
    "addExternalServerScreen.namePlaceholder":"请输入服务器名称",
    "addExternalServerScreen.ipTextBoxLabel":"服务器地址",
    "addExternalServerScreen.portTextBoxLabel":"端口",
    "addExternalServerScreen.ipPlaceholder":"请输入 IP 或地址",
    "addExternalServerScreen.alreadyAdded":"此服务器已被添加",
    "addExternalServerScreen.saveButtonLabel":"保存",
    "addExternalServerScreen.playButtonLabel":"游戏",
    "addExternalServerScreen.removeButtonLabel":"移除",
    "addExternalServerScreen.removeConfirmation":"确定要移除此服务器吗？",
    "addExternalServerScreen.addTitle":"添加外部服务器",
    "addExternalServerScreen.editTitle":"编辑外部服务器",

}