dressingRoom: dict = {
    "dressingRoom.skin_color_picker_title":"皮肤颜色",

}