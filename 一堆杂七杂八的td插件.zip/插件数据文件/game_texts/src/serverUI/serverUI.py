serverUI: dict = {
    "serverUI.errorTitle":"创建表单时出错。",
    "serverUI.errorDescription":"接收的表单 json 无效。错误：%s",

}