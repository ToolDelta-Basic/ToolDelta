comment: dict = {
    "comment.like":"%d 个赞						 1 like",
    "comment.likes":"%d 个赞						 0 or 2+ likes",
    "comment.comment":"%d 个评论					 1 comment",
    "comment.comments":"%d 个评论				 0 or 2+ comments",
    "comment.likes_and_comments":"%1 和 %2		 comment.like(s) will be inserted at %1 and comment.comment(s) at %2",
    "comment.commentplaceholder":"评论...",

}