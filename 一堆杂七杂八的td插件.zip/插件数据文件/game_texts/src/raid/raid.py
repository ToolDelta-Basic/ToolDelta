raid: dict = {
    "raid.name":"劫掠",
    "raid.progress":"剩余生物：",
    "raid.expiry":"一个副本已过期",
    "raid.victory":"胜利",
    "raid.defeat":"失败",

}