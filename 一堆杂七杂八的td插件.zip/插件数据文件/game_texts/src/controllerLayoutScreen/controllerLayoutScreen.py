controllerLayoutScreen: dict = {
    "controllerLayoutScreen.actions":"动作",
    "controllerLayoutScreen.activeBindingNameFormat":"> %s <",
    "controllerLayoutScreen.bindings":"绑定",
    "controllerLayoutScreen.resetAllBindings":"默认设置",
    "controllerLayoutScreen.button":"按钮",
    "controllerLayoutScreen.cancel":"取消",
    "controllerLayoutScreen.confirmation.reset":"是否确实要重置设置？",
    "controllerLayoutScreen.confirmation.unassigned":"保存未设置的操作？",
    "controllerLayoutScreen.confirmation.unsaved":"退出且不保存？",
    "controllerLayoutScreen.save":"保存",
    "controllerLayoutScreen.saveAndExit":"保存&退出",
    "controllerLayoutScreen.trigger":"触发键",
    "controllerLayoutScreen.unassigned":"未指派",
    "controllerLayoutScreen.toggleLivingroom":"切换沉浸模式",

}