utility: dict = {
    "utility.zipFile":"Zip 文件",
    "utility.pdfFile":"PDF 文件",

}