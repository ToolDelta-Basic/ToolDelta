realmsPlus: dict = {
    "realmsPlus.popup.top_button_text":"更多信息",
    "realmsPlus.popup.bottom_button_text":"续订",
    "realmsPlus.popup.title":"Realms Plus 订阅已过期",
    "realmsPlus.popup.message":"您的 Realms Plus 订阅已过期。为了能够重新访问您的 Realm 和您从 Realms Plus 获得的包和皮肤，您需要进行续订。",

}