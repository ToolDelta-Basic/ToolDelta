controls: dict = {
    "controls.reset":"重置",
    "controls.resetAll":"重置按键",
    "controls.title":"控制",

}