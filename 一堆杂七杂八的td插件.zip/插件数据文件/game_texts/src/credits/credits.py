credits: dict = {
    "credits.skip":"跳过",

}