roaming: dict = {
    "roaming.status_brief.limited_usage":"限制使用",
    "roaming.status_brief.no_restrictions":"跨平台可用",
    "roaming.status_hover.limited_usage":"只能在特定平台上使用。",
    "roaming.status_hover.no_restrictions":"适用于任何 Bedrock 平台！",

}