review: dict = {
    "review.item.post.rating.dropdown.label":"选择星级",
    "review.item.post.rating.footer":"您可以更改自己的评级。",
    "review.item.post.rating.submit.button":"为此包评级",
    "review.item.post.rating.1star":"很抱歉得知您完全不喜欢您的皮肤包。使用下面的按钮让创作者知道他们可以如何改进。",
    "review.item.post.rating.2star":"那可不太好。使用下面的按钮让创作者知道他们可以如何改进。",
    "review.item.post.rating.3star":"虽然一直有需要完善的地方，但我们很高兴您仍能畅享其中。",
    "review.item.post.rating.4star":"我们很高兴您能欢度美好时光！",
    "review.item.post.rating.5star":"哦呵！我们很高兴您能欢度美好时光！",
    "review.item.post.rating.submit.toast.line1":"感谢您为此包评分！",
    "review.item.post.rating.submit.toast.line2":"显示您的评级需要一些时间。",

}