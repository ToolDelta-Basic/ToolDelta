permissionsScreen: dict = {
    "permissionsScreen.kick":"踢出玩家",
    "permissionsScreen.ban":"封禁玩家",

}