authserver: dict = {
    "authserver.notavailable":"出错了。我们无法验证您尝试连接的服务器是我们信任的服务器。我们建议您稍后再试。",
    "authserver.authfailed":"太糟糕了。该服务器未能通过我们的验证测试。我们不信任的服务器可能正假装成受信任服务器。",

}