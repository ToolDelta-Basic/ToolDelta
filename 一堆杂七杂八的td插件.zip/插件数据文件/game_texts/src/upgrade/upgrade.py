upgrade: dict = {
    "upgrade.netherite_upgrade.name":"下界合金升级",

}