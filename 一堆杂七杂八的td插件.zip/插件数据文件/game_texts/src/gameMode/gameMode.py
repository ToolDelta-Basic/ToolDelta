gameMode: dict = {
    "gameMode.adventure":"冒险模式",
    "gameMode.changed":"您的游戏模式已更新为 %s",
    "gameMode.creative":"创造模式",
    "gameMode.hardcore":"极限模式！",
    "gameMode.spectator":"旁观模式",
    "gameMode.survival":"生存模式",

}