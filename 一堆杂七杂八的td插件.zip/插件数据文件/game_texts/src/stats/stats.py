stats: dict = {
    "stats.tooltip.type.achievement":"成就",
    "stats.tooltip.type.statistic":"统计",

}