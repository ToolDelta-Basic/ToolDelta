xblLogin: dict = {
    "xblLogin.LoginMessageTitle":"Microsoft 账户",
    "xblLogin.LoginMessage":"连接中...",

}