pack: dict = {
    "pack.authors.label":"作者：%s",
    "pack.authors.none":"未知",

}