eduTemplateWorld: dict = {
    "eduTemplateWorld.theAgentTrials.name":"代理机器人试玩",
    "eduTemplateWorld.tutorialWorld.name":"教程世界",
    "eduTemplateWorld.mushroomIsland.name":"蘑菇岛",
    "eduTemplateWorld.mooshroomIsland.name":"蘑菇岛",
    "eduTemplateWorld.starterTown.name":"新手村",
    "eduTemplateWorld.tutorialVolumeII.name":"教程第 II 卷",
    "eduTemplateWorld.blocksOfGrass.name":"草地块",

}