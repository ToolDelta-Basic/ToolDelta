patchNotes: dict = {
    "patchNotes.loading":"正在加载补丁说明",
    "patchNotes.continue":"继续",
    "patchNotes.unlock":"解锁",
    "patchNotes.error.noInternet.title":"已从互联网断开连接",
    "patchNotes.error.noInternet.msg":"槽糕！出错了。也许您可以检查一下互联网连接？",
    "patchNotes.error.notFound.title":"补丁说明 %1",
    "patchNotes.error.notFound.msg":"我们在本次发布中修复了几个漏洞。当我们有更多的信息需要告知您的时候，我们会向您发送新的补丁说明。",

}