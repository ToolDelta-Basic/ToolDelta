date: dict = {
    "date.short_january":"一月",
    "date.short_february":"二月",
    "date.short_march":"三月",
    "date.short_april":"四月",
    "date.short_may":"五月",
    "date.short_june":"六月",
    "date.short_july":"七月",
    "date.short_august":"八月",
    "date.short_september":"九月",
    "date.short_october":"十月",
    "date.short_november":"十一月",
    "date.short_december":"十二月",
    "date.formatted":"%s %d %d",
    "date.formatted_alt":"%d %s %d",

}