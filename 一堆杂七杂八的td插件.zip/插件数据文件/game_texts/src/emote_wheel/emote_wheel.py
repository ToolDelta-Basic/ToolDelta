emote_wheel: dict = {
    "emote_wheel.gamepad_helper.select":"点按以选择",

}