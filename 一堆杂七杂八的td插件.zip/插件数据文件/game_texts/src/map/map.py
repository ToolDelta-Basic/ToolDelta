map: dict = {
    "map.toolTip.displayMarkers":"显示标记",
    "map.toolTip.scaling":"缩放比例：",
    "map.toolTip.level":"等级%s/%s",
    "map.toolTip.unkown":"未知地图",
    "map.toolTip.locked":"已锁定",
    "map.position.agent":"代理机器人位置：%s，%s，%s",
    "map.position":"位置：%s, %s, %s",
    "map.rename":"重命名地图",
    "map.basicMap":"基础地图",
    "map.locatorMap":"会显示玩家的地图",
    "map.extendAndClear":"缩小和清除",
    "map.clone":"复制地图",
    "map.name":"地图名称",
    "map.lock":"锁定地图",

}