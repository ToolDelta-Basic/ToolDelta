quiz: dict = {
    "quiz.popup.ok":"参加测验",
    "quiz.popup.text":"测验将在新窗口中打开。 完成测验后您就可以返回《我的世界》了。",
    "quiz.popup.title":"测验",

}