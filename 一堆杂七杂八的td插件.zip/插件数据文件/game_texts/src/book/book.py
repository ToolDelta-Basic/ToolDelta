book: dict = {
    "book.byAuthor":"作者",
    "book.defaultAuthor":"未知作者",
    "book.editTitle":"输入书名：",
    "book.export":"导出",
    "book.finalizeButton":"签名并关闭",
    "book.finalizeWarning":"注意！在你签名后，书籍将无法再修改。",
    "book.generation.0":"原作",
    "book.generation.1":"原件的副本",
    "book.generation.2":"副本的副本",
    "book.generation.3":"破烂不堪",
    "book.pageIndicator":"第 %1$s 页 共 %2$s 页",
    "book.signButton":"签名",
    "book.titleHere":"[在此处输入书名]",
    "book.headerPortfolio":"来自相片簿",
    "book.headerInventory":"来自物品栏",

}