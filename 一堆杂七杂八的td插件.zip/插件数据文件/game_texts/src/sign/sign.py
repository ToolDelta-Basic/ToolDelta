sign: dict = {
    "sign.edit":"修改告示牌信息",

}