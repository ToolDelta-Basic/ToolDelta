notification: dict = {
    "notification.lock.noCraft":"此物品已锁定，无法合成",
    "notification.lock.noDrop":"此物品已锁定，无法丢弃",
    "notification.lock.noRemove":"此物品已锁定，无法从物品栏中删除",

}