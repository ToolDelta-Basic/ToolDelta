onlinePlay: dict = {
    "onlinePlay.notRated":"线上游戏未分级",
    "onlinePlay.message":"线上游戏可能会含有聊天消息或其他用户创作的内容，这些内容未经评级，可能并不适合所有年龄段。",
    "onlinePlay.editor.notRated":"在线编辑未分级",
    "onlinePlay.editor.message":"在线编辑期间可能会含有聊天消息或其他用户创作的内容，这些内容未经评级，可能并不适合所有年龄段。",
    "onlinePlay.doNotShowAgain":"不再显示此窗口",
    "onlinePlay.proceed":"继续",
    "onlinePlay.Back":"返回",
    "onlinePlay.untrustedIp.title":"未知的外部服务器",
    "onlinePlay.untrustedIp.message":"您应该只连接到信任的服务器！仍想加入吗？",

}