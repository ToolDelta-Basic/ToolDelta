lateJoinScreen: dict = {
    "lateJoinScreen.waitingForUserReady":"正在准备",

}