soundCategory: dict = {
    "soundCategory.ambient":"环境",
    "soundCategory.block":"方块",
    "soundCategory.hostile":"敌对生物",
    "soundCategory.main":"主要",
    "soundCategory.music":"音乐",
    "soundCategory.neutral":"友好生物",
    "soundCategory.player":"玩家",
    "soundCategory.record":"唱片机/音符盒",
    "soundCategory.weather":"天气",
    "soundCategory.texttospeech":"文字转语音输出",

}