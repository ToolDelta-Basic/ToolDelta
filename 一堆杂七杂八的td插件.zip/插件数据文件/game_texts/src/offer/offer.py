offer: dict = {
    "offer.category.skinpack":"皮肤包",
    "offer.category.resourcepack":"材质包",
    "offer.category.mashup":"混搭包",
    "offer.category.worldtemplate":"世界",
    "offer.category.editorschoice":"编辑的选择",
    "offer.category.allByCreator":"创作者：%s",
    "offer.navigationTab.skins":"皮肤",
    "offer.navigationTab.textures":"材质",
    "offer.navigationTab.worlds":"世界",
    "offer.navigationTab.mashups":"混搭包",

}