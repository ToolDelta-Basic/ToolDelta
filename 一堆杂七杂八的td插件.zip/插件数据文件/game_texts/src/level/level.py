level: dict = {
    "level.launch.failed":"启动失败",
    "level.export.started":"世界导出已开始...",
    "level.import.started":"世界导入已开始...",
    "level.export.success":"世界导出成功完成",
    "level.import.success":"世界导入成功完成",
    "level.export.failed":"世界导出失败",
    "level.import.failed":"世界导入失败",
    "level.import.failed.incompatibleEdition":"世界导入失败：出现了不支持的格式。",
    "level.editor.export.started":"项目导出已开始...",
    "level.editor.import.started":"项目导入已开始...",
    "level.editor.export.success":"项目导出成功完成",
    "level.editor.import.success":"项目导入成功完成",
    "level.editor.export.failed":"项目导出失败",
    "level.editor.import.failed":"项目导入失败",
    "level.editor.import.failed.incompatibleEdition":"项目导入失败：出现了不支持的文件格式",

}