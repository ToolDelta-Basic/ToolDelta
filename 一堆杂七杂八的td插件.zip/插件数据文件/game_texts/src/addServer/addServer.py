addServer: dict = {
    "addServer.add":"完成",
    "addServer.enterIp":"服务器地址",
    "addServer.enterName":"服务器名称",
    "addServer.hideAddress":"隐藏地址",
    "addServer.resourcePack":"服务器资源包",
    "addServer.resourcePack.disabled":"已禁用",
    "addServer.resourcePack.enabled":"启用",
    "addServer.resourcePack.prompt":"提示",
    "addServer.title":"编辑服务器信息",
    "addServer.alreadyAdded":"此服务器已被添加",

}