furnaceScreen: dict = {
    "furnaceScreen.fuel":"燃料",
    "furnaceScreen.header":"熔炉",
    "furnaceScreen.input":"输入",
    "furnaceScreen.result":"结果",

}