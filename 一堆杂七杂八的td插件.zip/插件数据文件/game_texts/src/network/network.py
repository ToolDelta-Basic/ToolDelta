network: dict = {
    "network.onlinePlay.title":"与好友一起玩",
    "network.onlinePlay.msg":"您可以邀请好友加入您的世界、查看好友的作品，并在各自的世界中制作物品。",
    "network.onlinePlay.instruction":"通过“游戏”菜单，您可以加入好友的世界，也可以邀请他们加入您的世界和 Realms。",
    "network.thirdparty.connect.splitscreen":"要在线玩分屏多人游戏，请登录至 %s 账户。",
    "network.thirdparty.connect.benefit":"使用您的 %s 登录来与好友进行在线游戏，并查看商店内超酷的物品。",
    "network.thirdparty.connect.store":"您将需要 %s 来浏览商店。",
    "network.thirdparty.connect.achievements":"您将需要 %s 来赢取成就。",
    "network.thirdparty.findfriends.failed":"我们无法连接到 Microsoft 账户服务。也许检查一下您的网络连接？",

}