mount: dict = {
    "mount.onboard":"按下 %1$s 来脱离",

}