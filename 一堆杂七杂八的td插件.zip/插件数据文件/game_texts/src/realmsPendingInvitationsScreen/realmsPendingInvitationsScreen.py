realmsPendingInvitationsScreen: dict = {
    "realmsPendingInvitationsScreen.pendingInvitations":"Realms 成员邀请",
    "realmsPendingInvitationsScreen.noInvites":"你没有待处理邀请。",
    "realmsPendingInvitationsScreen.fetchingInvites":"正在获取邀请...",
    "realmsPendingInvitationsScreen.decline":"拒绝",
    "realmsPendingInvitationsScreen.accepted":"已接受",
    "realmsPendingInvitationsScreen.declined":"已拒绝",
    "realmsPendingInvitationsScreen.showFriendInvites":"只显示来自好友的邀请。",

}