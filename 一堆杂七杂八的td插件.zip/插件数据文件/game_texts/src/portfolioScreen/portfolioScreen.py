portfolioScreen: dict = {
    "portfolioScreen.page":"第 %s 页",
    "portfolioScreen.export":"导出相片簿",
    "portfolioScreen.caption":"[ 标题 ]",
    "portfolioScreen.nopics0":"您的相片簿中目前没有照片。您用摄像机拍摄的照片将显示在这里。您也可以使用下面的按钮进行添加。",
    "portfolioScreen.nopics1":"用摄像机拍摄的照片将显示在此处。",
    "portfolioScreen.noInventory":"你的物品栏中没有任何照片。尝试使用相机拍照。",
    "portfolioScreen.addPhoto":"添加照片",

}