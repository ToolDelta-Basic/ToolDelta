translation: dict = {
    "translation.test.args":"%s %s",
    "translation.test.complex":"前缀，%s%2$s，然后是 %s 和 %1$s，最后是 %s，还有 %1$s！",
    "translation.test.escape":"%%s %%%s %%%%s %%%%%s",
    "translation.test.invalid":"% 你好",
    "translation.test.invalid2":"%s 你好",
    "translation.test.none":"你好，世界！",
    "translation.test.world":"世界",

}