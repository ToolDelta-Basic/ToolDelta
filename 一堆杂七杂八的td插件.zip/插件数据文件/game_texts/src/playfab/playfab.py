playfab: dict = {
    "playfab.account.banned.temporary":"暂停",
    "playfab.account.banned.permanent":"禁止",
    "playfab.account.banned.title":"您已被%s",
    "playfab.account.banned.body":"您已被%s玩《我的世界》多人游戏。您将无法在服务器上玩游戏、加入 Realms、主办游戏、加入多人游戏或是访问市场。",
    "playfab.account.banned.body.line1":"由于“%s”，您已被%s玩《我的世界》多人游戏。您将无法在服务器上玩游戏、加入 Realms、主办游戏、加入多人游戏或是访问市场。",
    "playfab.account.banned.body.line2":"点击下方的“%s”查看我们的社群规则，以及当您认为自己遇到%s错误时该如何提交案例审核请求。",
    "playfab.account.banned.body.line3.hour":"您的冻结还剩 1 小时。",
    "playfab.account.banned.body.line3.hours":"您的冻结还剩 %d 小时。",
    "playfab.account.banned.body.line3.day":"您的冻结还剩 1 天。",
    "playfab.account.banned.body.line3.days":"您的冻结还剩 %d 天。",
    "playfab.account.banned.body.line3.forever":"此次封禁是永久生效的。",
    "playfab.account.banned.body.button":"更多信息",

}