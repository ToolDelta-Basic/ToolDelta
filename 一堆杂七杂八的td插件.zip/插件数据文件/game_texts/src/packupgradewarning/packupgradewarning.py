packupgradewarning: dict = {
    "packupgradewarning.invalidpacktype":"所提供的 '%s' 元素具有包清单中的无效值；默认为资源包。",
    "packupgradewarning.required_manifest_property_missing":"包清单中缺少 '%s' 元素；默认为 '%s'。",
    "packupgradewarning.required_manifest_property_empty":"包清单中的必备 '%s' 元素为空；默认为 '%s'。",
    "packupgradewarning.malformed_uuid":"所提供的 '%s' 元素在包清单中不是有效的 UUID；默认为 '%s'。",
    "packupgradewarning.malformed_version":"所提供的 '%s' 元素在包清单中不兼容 SemVer (semver.org)；默认为 '%s'。",
    "packupgradewarning.manifest_upgraded":"此包清单已升级到新版本。",
    "packupgradewarning.duplicate_uuid":"所提供的 UUID '%s' 元素已存在于包清单中；默认为 '%s'。",
    "packupgradewarning.multiple_modules":"包清单中检测到多个冲突的模块；默认为 '%s'。",

}