emotes: dict = {
    "emotes.change_emotes":"更改表情",
    "emotes.execute":"执行",
    "emotes.header_text":"表情",
    "emotes.emotes_instructions_general":"使用热键或鼠标激活表情",
    "emotes.exit_gamepad":"%s 退出",
    "emotes.instructions_gamepad":"要在游戏中快速播放表情符号，您可以随时按住 %s 以获取快捷菜单",
    "emotes.instructions_keyboard":"使用热键或鼠标激活表情",
    "emotes.instructions_touch":"点击表情以激活",

}