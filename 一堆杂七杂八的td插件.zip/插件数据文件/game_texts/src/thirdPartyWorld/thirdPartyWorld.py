thirdPartyWorld: dict = {
    "thirdPartyWorld.comingSoon":"即将推出！",
    "thirdPartyWorld.Featured":"精选服务器",
    "thirdPartyWorld.Additional":"其他服务器",
    "thirdPartyWorld.featuredComingSoon":"即将推出",
    "thirdPartyWorld.notConnected":"目前无法连接至服务器。我们会稍后再试。",
    "thirdPartyWorld.playNow":"立即开玩！",
    "thirdPartyWorld.loadingServers":"正在检索服务器信息，请稍候...",
    "thirdPartyWorld.loadingFeaturedServers":"正在获取服务器...",

}