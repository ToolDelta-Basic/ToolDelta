gameArgument: dict = {
    "gameArgument.featureUnsupported":"该版本的《我的世界》不支持此功能",

}