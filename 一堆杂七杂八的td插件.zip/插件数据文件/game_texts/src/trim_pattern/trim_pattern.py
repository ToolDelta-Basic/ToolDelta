trim_pattern: dict = {
    "trim_pattern.coast.name":"海岸纹饰盔甲",
    "trim_pattern.dune.name":"沙丘纹饰盔甲",
    "trim_pattern.eye.name":"眼眸纹饰盔甲",
    "trim_pattern.host.name":"主导盔甲纹饰",
    "trim_pattern.raiser.name":"崛起盔甲纹饰",
    "trim_pattern.rib.name":"肋骨纹饰盔甲",
    "trim_pattern.sentry.name":"哨兵纹饰盔甲",
    "trim_pattern.shaper.name":"塑形盔甲纹饰",
    "trim_pattern.silence.name":"潜声盔甲纹饰",
    "trim_pattern.snout.name":"猪鼻纹饰盔甲",
    "trim_pattern.spire.name":"尖顶纹饰盔甲",
    "trim_pattern.tide.name":"潮汐纹饰盔甲",
    "trim_pattern.vex.name":"恼鬼纹饰盔甲",
    "trim_pattern.ward.name":"监守纹饰盔甲",
    "trim_pattern.wayfinder.name":"寻路盔甲纹饰",
    "trim_pattern.wild.name":"荒野纹饰盔甲",

}