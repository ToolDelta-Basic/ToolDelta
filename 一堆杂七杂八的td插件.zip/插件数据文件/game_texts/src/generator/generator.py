generator: dict = {
    "generator.amplified":"放大化",
    "generator.amplified.info":"注意：只是为了好玩，需要较高配置的电脑",
    "generator.customized":"自定义",
    "generator.debug_all_block_states":"调试模式",
    "generator.default":"默认",
    "generator.flat":"平坦",
    "generator.infinite":"无限",
    "generator.largeBiomes":"大型生物群系",
    "generator.nether":"下界",
    "generator.old":"有限",
    "generator.void":"虚空",

}