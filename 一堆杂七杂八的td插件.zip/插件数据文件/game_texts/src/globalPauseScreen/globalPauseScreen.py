globalPauseScreen: dict = {
    "globalPauseScreen.message":"游戏已暂停",
    "globalPauseScreen.quit":"退出",

}