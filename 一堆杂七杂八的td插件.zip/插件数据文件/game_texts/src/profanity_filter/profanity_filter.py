profanity_filter: dict = {
    "profanity_filter.title":"猥亵语言过滤器",
    "profanity_filter.msg":"您输入的文本包含可能对他人具有冒犯性的词汇，因此无法使用。请重试。",

}