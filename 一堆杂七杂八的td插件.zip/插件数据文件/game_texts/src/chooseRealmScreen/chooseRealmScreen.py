chooseRealmScreen: dict = {
    "chooseRealmScreen.header":"选择一个 Realm 服务器",
    "chooseRealmScreen.realmsplusbuttontext":"添加一个 10 名玩家的 Realm",
    "chooseRealmScreen.realmsbuttontext":"添加一个 2 名玩家的 Realm",

}