exports: dict = {
    "exports.share.file":"分享 %s",
    "exports.suspendWarning.client.content":"警告：如果您继续，您将与该多人游戏会话断开连接。",
    "exports.suspendWarning.host.content":"警告：如果您继续，这将结束所有玩家的多人游戏会话。",
    "exports.suspendWarning.title":"警告",
    "exports.fileError.title":"无法保存您的文件",
    "exports.fileError.body":"磁盘可能已满或受到写入保护，或此文件可能正在使用。请检查以确保该文件未打开，然后重试。",

}