worldError: dict = {
    "worldError.corrupted":"已毁坏并无法启动。",
    "worldError.invalidArguments":"以无效参数创建。",
    "worldError.IO":"无法打开。",
    "worldError.notFound":"无法找到。",
    "worldError.notSupported":"出现了不支持的格式。",
    "worldError.unknown":"出现了未知问题。",
    "worldError.writeCorrupted":"已毁坏，无法保存。",
    "worldError.worldRecovered":"世界已恢复",
    "worldError.recoveredCorruptedWorld":"成功地恢复了您已损坏的世界。",
    "worldError.recoveredCorruptedWorldWarning":"您最近的一些更改可能已在恢复过程中丢失。",
    "worldError.worldFailedRecovery":"恢复失败",
    "worldError.worldFailedRecoveryText":"我们检测到了一个损坏的世界，但未能恢复它。",

}