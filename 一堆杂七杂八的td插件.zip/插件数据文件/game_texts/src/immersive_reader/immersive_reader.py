immersive_reader: dict = {
    "immersive_reader.book_page_header":"第 %1 页，共 %2 页",
    "immersive_reader.portfolio_page_header":" 第 %1 页",
    "immersive_reader.error.webview_failure":"连接到沉浸式阅读器时出现了问题。",
    "immersive_reader.error.identity_failure":"连接到沉浸式阅读器时出现了问题。请重启 Minecraft Education 并重试。",

}