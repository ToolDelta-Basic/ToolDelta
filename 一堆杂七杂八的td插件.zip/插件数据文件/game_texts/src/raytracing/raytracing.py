raytracing: dict = {
    "raytracing.RTX.name":"RTX	Brand name, don't localize",

}